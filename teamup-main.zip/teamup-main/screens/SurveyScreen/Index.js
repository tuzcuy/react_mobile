export {default} from './SurveyScreen';
