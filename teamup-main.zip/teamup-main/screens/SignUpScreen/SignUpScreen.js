import React, {useState} from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import SocialSignInButtons from '../../components/SocialSignInButtons';
import {useNavigation} from '@react-navigation/native';
import CustomMultiPicker from "react-native-multiple-select-list";
import { auth } from '../../Firebase'
import { db } from '../../Firebase';
import {collection, getDocs } from 'firebase/firestore';

const SportList = {
  "1":"Football",
  "2":"BasketBall",
  "3":"Tennis"
}

const SignUpScreen = () => {
  const navigation = useNavigation();
 
  const [name, setname] = useState('');
  const [surname, setSurname] = useState('');
  const [age, setAge] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordRepeat, setPasswordRepeat] = useState('');
  
 const onRegisterPressed = () => navigation.navigate("ConfirmEmailScreen");
 const onSignInPress = () => navigation.navigate("Signin")
  



  const onTermsOfUsePressed = () => {
    console.warn('onTermsOfUsePressed');
  };

  const onPrivacyPressed = () => {
    console.warn('onPrivacyPressed');
  };
  const handleSignUp = () => {
    auth
      .createUserWithEmailAndPassword(email, password)
      .then(userCredentials => {
        const user = userCredentials.user;
        console.log('Registered with:', user.email);
      })
      .catch(error => alert(error.message))
  }
  const setData = async () =>{
    const nname = name;
    const ssurname = surname;
    const aage = age;
    const uusername = username;
    const eemail = email;
    const ppassword=password;


   
    
    db.collection("Users").doc(uusername).set({
     name : nname,
     surname: ssurname,
     age : aage,
     username : uusername,
     email : eemail,
     password : ppassword
     
    
  })
  .then(() => {
      console.log("User successfully added!");
  })
  .catch((error) => {
      console.error("Error writing document: ", error);
  });

  }

  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.root}>
        <Text style={styles.title}>Create an account</Text>
        <CustomInput
          placeholder="Name"
          value={name}
          setValue={setname}
        />
        <CustomInput
          placeholder="Surname"
          value={surname}
          setValue={setSurname}
        />
        <CustomInput
          placeholder="Age"
          value={age}
          setValue={setAge}
        />
        
        <CustomInput
          placeholder="Username"
          value={username}
          setValue={setUsername}
        />
        <CustomInput placeholder="Email" value={email} setValue={setEmail} />
        <CustomInput
          placeholder="Password"
          value={password}
          setValue={setPassword}
          secureTextEntry
        />
        <CustomInput
          placeholder="Repeat Password"
          value={passwordRepeat}
          setValue={setPasswordRepeat}
          secureTextEntry
        />
        
       
    

        <CustomButton text="Confirm" onPress={setData}  />
        <CustomButton text="Register" onPress={handleSignUp}  />
        <CustomButton text="Have an account? Sign in"onPress={onSignInPress}type="TERTIARY"/>

        <Text style={styles.text}>
          By registering, you confirm that you accept our{' '}
          <Text style={styles.link} onPress={onTermsOfUsePressed}>
            Terms of Use
          </Text>{' '}
          and{' '}
          <Text style={styles.link} onPress={onPrivacyPressed}>
            Privacy Policy
          </Text>
        </Text>

        <SocialSignInButtons />

        
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#051C60',
    margin: 10,
  },
  text: {
    color: 'gray',
    marginVertical: 10,
  },
  link: {
    color: '#FDB075',
  },
});

export default SignUpScreen;